<div id="app">
@include('layouts.shared.navbar')
    <main class="py-4">
        @yield('content')
    </main>
</div>
