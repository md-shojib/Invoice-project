<?php $__env->startSection('CssSection'); ?>
    <link href="<?php echo e(asset('css/UserLayout.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success"><?php echo e(session('status')); ?></div>
    <?php endif; ?>
    <div class="container">
        <h1 class="title text-center">Personal Information</h1>
        <div class="row">
            <div class="col-12">
                <div class="media mb-4">
                    <img class="rounded-circle account-img" src="<?php echo e(Storage::disk('uploads')->url($profile->profile_pic)); ?>" style="width: 200px;">

                    <div class="media-body mb-4">
                        <h2 class="account-heading"><?php echo e($profile->name); ?></h2>
                        <p class="text-secondary"><?php echo e($profile->email); ?></p>
                    </div>
                </div>
                <form method ="POST" enctype="multipart/form-data" action="<?php echo e(route('updateProfile', \Illuminate\Support\Facades\Auth::user()->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <label for="name">Name: </label>
                    <input type="text" name="name" id="name" placeholder="Name" value="<?php echo e($profile->name); ?>"/><br>
                    <span id="Spannumber" class="error"><?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span> <br>

                    <label id="icon" for="number">Phone Number: </label>
                    <input type="number" name="number" id="number" placeholder="Phone Number" value="<?php echo e($profile->phone_number); ?>"/><br>
                    <span id="Spannumber" class="error"><?php $__errorArgs = ['phone_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span> <br>
                       <label for="gender">Gender:</label>

                    <select name="gender" id="gender">

                        <?php if(isset($profile->gender)): ?>
                            <option value="<?php echo e($profile->gender->id??""); ?>"><?php echo e($profile->gender->name??""); ?></option>
                        <?php $__currentLoopData = $gender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($g->id!==$profile->gender->id): ?>
                                <option value="<?php echo e($g->id); ?>"><?php echo e($g->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <?php $__currentLoopData = $gender; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($g->id); ?>"><?php echo e($g->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select>
                    <label for="status">Status:</label>

                    <select name="status" id="status">

                        <?php if(isset($profile->status)): ?>
                            <option value="<?php echo e($profile->status->id??""); ?>"><?php echo e($profile->status->name??""); ?></option>
                        <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($s->id!==$profile->status->id): ?>
                                <option value="<?php echo e($s->id); ?>"><?php echo e($s->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <?php $__currentLoopData = $status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($s->id); ?>"><?php echo e($s->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </select><br>
                    <label for="file_image">Upload Cover Image: </label>
                    <input type="file" name="file_image" class="form-control" value="<?php echo e($profile->filename); ?>">
                    <span id="Spanfile" class="error"><?php $__errorArgs = ['filename'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span> <br>





                    <button class="updatebutton" type="submit">Update</button>

                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shojib/Desktop/project/Invoice-System-master/resources/views/Profile/ProfileForm.blade.php ENDPATH**/ ?>