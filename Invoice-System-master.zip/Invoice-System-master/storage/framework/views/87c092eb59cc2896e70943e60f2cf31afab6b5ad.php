<?php $__env->startSection('CssSection'); ?>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/InvoiceForm.css')); ?>">
    <?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <div class="contain">
        <?php if(session('status')): ?>
            <div class="alert alert-success"><?php echo e(session('status')); ?></div>
        <?php endif; ?>
        <?php if(isset($invoice)): ?>
                <form method="post" action="<?php echo e(route('invoice.update', $invoice->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                    <div id="invoice">
                        <form id="AddForm" name="addForm" method="post">
                            <?php echo csrf_field(); ?>
                            <div id="item-container">
                                <?php $__currentLoopData = $arr; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k=>$v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $v; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div>
                                        <input type="text" id="iName" class="iName" name="iName[]" onkeyup="abcd(Increment)"  placeholder="Item Name" value="<?php echo e($value['name']); ?>">
                                        <input type="number" id="cost" class="cost" name="cost[]" placeholder="Unit cost" value="<?php echo e($value['cost']); ?>">
                                        <input type="number" id="quantity" name="qty[]" onkeyup="itemValue(Increment)" placeholder="Quantity" value="<?php echo e($value['quantity']); ?>">
                                        <button type="button" id="bt" onclick="return this.parentNode.remove();">Delete</button><br>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <ul id="myUL"></ul>
                            <a id="add-new-item">Add new item</a>
                        </form><br>
                        <span id="SpanForm" class="error"><?php $__errorArgs = ['addForm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span> <br>
                        <div id="items"></div>
                        <label for="cost">Cost without discount</label><br>

                        <input type="text" id="cost_wod" name="cost_wod" class="cost_wod" value="<?php echo e($invoice->total_cost); ?>" autocomplete="off"><br>
                        <span id="SpanCost" class="error"><?php $__errorArgs = ['cost_wod'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span> <br>

                        <label for="discount">Discount in %</label><br>
                        <input type="text" id="discount" name="discount" class="discountcost" size="50" value=10 ><br>
                        <span id="SpanDiscount" class="error"><?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span> <br>

                        <label for="tax">Tax %</label><br>
                        <input type="text" id="tax" name="tax" class="tax" size="50" value=5><br>
                        <span id="SpanTax" class="error"><?php $__errorArgs = ['tax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span> <br>

                        <label for="dcost">Cost with discount and tax</label><br>
                        <input type="text" id="dcost" name="dcost" class="dcost" value="<?php echo e($invoice->final_cost); ?>" autocomplete="off"><br>
                        <span id="SpanDcost" class="error"><?php $__errorArgs = ['dcost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span> <br>

                        <label for="advance">Advance payment</label><br>
                        <input type="text" id="advance" name="advance" class="advance" onkeypress="AdvanceValue()"
                               onkeyup="AdvanceValue()" value="<?php echo e($invoice->advance); ?>" autocomplete="off"><br>
                        <span id="SpanAdvance" class="error"><?php $__errorArgs = ['advance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span> <br>

                        <label for="due">Due amount</label><br>
                        <input type="text" id="due" name="due" class="due" value="<?php echo e($invoice->due); ?>" autocomplete="off"><br>
                        <span id="SpanDue" class="error"><?php $__errorArgs = ['due'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span> <br>


                        <button type="submit" id="submit">Update</button>
                    </div>
                </form>
    </div>
    <?php else: ?>
        <form method="post" action="<?php echo e(route('invoice.store')); ?>">
            <?php echo csrf_field(); ?>
        <div id="invoice">
            <form id="AddForm" name="addForm" method="post">
                <?php echo csrf_field(); ?>
                <div id="item-container">
                </div>
                <ul id="myUL"></ul>
                <a id="add-new-item">Add new item</a>
            </form><br>
            <span id="SpanForm" class="error"><?php $__errorArgs = ['addForm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span> <br>
            <div id="items"></div>
            <label for="cost">Cost without discount</label><br>
            <input type="text" id="cost_wod" name="cost_wod" class="cost_wod" value="<?php echo e(@old('cost_wod')); ?>" readonly><br>
            <span id="SpanCost" class="error"><?php $__errorArgs = ['cost_wod'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span> <br>

            <label for="discount">Discount in %</label><br>
            <input type="number" id="discount" name="discount" class="discountcost" size="50" value=10><br>
            <span id="SpanDiscount" class="error"><?php $__errorArgs = ['discount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span> <br>

            <label for="tax">Tax %</label><br>
            <input type="number" id="tax" name="tax" class="tax" size="50" value=5><br>
            <span id="SpanTax" class="error"><?php $__errorArgs = ['tax'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span> <br>

            <label for="dcost">Cost with discount and tax</label><br>
            <input type="text" id="dcost" name="dcost" class="dcost" readonly value="<?php echo e(@old('dcost')); ?>"><br>
            <span id="SpanDcost" class="error"><?php $__errorArgs = ['dcost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span> <br>

            <label for="advance">Advance payment</label><br>
            <input type="text" id="advance" name="advance" class="advance" onkeypress="AdvanceValue()"
                   onkeyup="AdvanceValue()" value="0"><br>
            <span id="SpanAdvance" class="error"><?php $__errorArgs = ['advance'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span> <br>

            <label for="due">Due amount</label><br>
            <input type="text" id="due" name="due" class="due" value="<?php echo e(@old('due')); ?>"><br>
            <span id="SpanDue" class="error"><?php $__errorArgs = ['due'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><?php echo e($message); ?><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></span> <br>


            <button type="submit" id="submit">Submit</button>
        </div>
        </form>
    </div>
    <?php endif; ?>
<?php $__env->startSection('JsSection'); ?>
    <script src="<?php echo e(asset('js/InvoiceForm.js')); ?>"></script>

<?php $__env->stopSection(); ?>
    <?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shojib/Desktop/project/Invoice-System-master/resources/views/InvoiceItem/InvoiceItemForm.blade.php ENDPATH**/ ?>