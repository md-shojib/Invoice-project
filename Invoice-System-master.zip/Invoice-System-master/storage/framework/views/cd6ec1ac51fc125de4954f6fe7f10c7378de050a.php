<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage_role')): ?>
<?php $__env->startSection('title'); ?> Audit Log <?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success"><?php echo e(session('status')); ?></div>
    <?php endif; ?>
    <?php if(session('error_msg')): ?>
        <div class="alert alert-success"><?php echo e(session('msg')); ?></div>
    <?php endif; ?>
    <?php $__currentLoopData = $audits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($audit->old_values !== []): ?>
        <?php if($audit->event==="updated"): ?>
        On <?php echo e($audit->created_at); ?>: <?php echo e($audit->user->name); ?> <?php echo e($audit->event); ?> from this record.
        <?php if(isset($audit->new_values['name'])): ?>
            Name from <?php echo e($audit->old_values['name']); ?> to
            <?php echo e($audit->new_values['name']); ?>

        <?php endif; ?>
        <?php if(isset($audit->new_values['email'])): ?>
            Name from <?php echo e($audit->old_values['email']); ?> to
            <?php echo e($audit->new_values['email']); ?>

        <?php endif; ?>
        <?php else: ?>
            On <?php echo e($audit->created_at); ?>: <?php echo e($audit->user->name); ?> <?php echo e($audit->event); ?> from this record.
            Deleted name is <?php echo e($audit->old_values['name']); ?>

            and deleted email is
            <?php echo e($audit->old_values['email']); ?>

        <?php endif; ?>
    <?php endif; ?><br>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shojib/Desktop/project/Invoice-System-master/resources/views/Audit/ShowAudits.blade.php ENDPATH**/ ?>