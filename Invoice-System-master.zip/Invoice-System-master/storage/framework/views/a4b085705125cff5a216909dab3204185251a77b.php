<div id="app">
<?php echo $__env->make('layouts.shared.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="py-4">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</div>
<?php /**PATH /home/shojib/Desktop/project/Invoice-System-master/resources/views/layouts/shared/header.blade.php ENDPATH**/ ?>