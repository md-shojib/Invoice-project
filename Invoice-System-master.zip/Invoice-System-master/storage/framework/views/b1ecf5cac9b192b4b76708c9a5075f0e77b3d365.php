<?php if(session('status')): ?>
    <div class="alert alert-success"><?php echo e(session('status')); ?></div>
<?php endif; ?>
<?php $__env->startSection('CssSection'); ?>
    <link href="<?php echo e(asset('css/UserLayout.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <a href="<?php echo e(route('invoice.create')); ?>">Add New Invoice</a>
    <div id="invoice_details">
        <table class="table table-hover" id="myTable">
            <thead>
            <tr>
                <th scope="col" class="page_sort" id="id">S No.</th>
                <th scope="col" class="page_sort" id="invoice">Invoice</th>
                <th scope="col" class="page_sort" id="name">Company</th>
                <th scope="col">View</th>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['update_invoice', 'delete_invoice'])): ?>
                <th scope="col">Edit</th>
                <th scope="col">Delete</th>
                <?php endif; ?>
            </tr>
            </thead>
            <tbody id="invoice_details_table">
            <?php $index=1;?>
            <?php $__currentLoopData = $invoice; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td ><?php echo e($index); ?></td>
                <td >Invoice<?php echo e($v->id); ?></td>
                <td ><?php echo e($v->company->name); ?></td>
                <td><a class="fa fa-eye" href="<?php echo e(route('invoice.show', $v->id)); ?>"></a></td>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['update_invoice', 'delete_invoice'])): ?>
                <td><a class="fa fa-edit" href="<?php echo e(route('invoice.edit', $v->id)); ?>"></a></td>
                <td>
                    <form action="<?php echo e(route('invoice.destroy', $v->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="fa fa-trash"></button>
                    </form>
                </td>
                <?php endif; ?>
            </tr>
                <?php $index++;?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shojib/Desktop/project/Invoice-System-master/resources/views/InvoiceItem/InvoiceItemView.blade.php ENDPATH**/ ?>