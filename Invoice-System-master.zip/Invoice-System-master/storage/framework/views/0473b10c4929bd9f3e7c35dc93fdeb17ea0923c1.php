<nav class="navbar navbar-expand-md navbar-light bg-white shadow-sm">
    <?php echo $__env->yieldContent('nav'); ?>
    <div class="container">

        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <!-- Left Side Of Navbar -->
            <ul class="navbar-nav mr-auto">
            <?php if(Auth::user()): ?>
                <?php if(auth()->user()->hasRole('admin')): ?>
                <ul>
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('Users')); ?>">USERS</a>
                    </li>
                </ul>

            <ul>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('role.index')); ?>">ROLES</a>
                </li>
            </ul>

                    <ul>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('audit')); ?>">AUDIT LOG</a>
                        </li>
                    </ul>

                    <ul>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('company.index')); ?>">COMPANY</a>
                        </li>
                    </ul>
                    <?php endif; ?>
                    <ul>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('invoice.index')); ?>">INVOICE</a>
                        </li>
                    </ul>

                    <ul>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('editProfile', \Illuminate\Support\Facades\Auth::user()->id)); ?>">PROFILE</a>
                        </li>
                    </ul>
            </ul>
            <?php endif; ?>

            <!-- Right Side Of Navbar -->
            <ul class="navbar-nav ml-auto">
                <!-- Authentication Links -->
                <?php if(auth()->guard()->guest()): ?>

                <?php else: ?>
                    <li class="nav-item dropdown">
                        <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                            <?php echo e(Auth::user()->name); ?>

                        </a>

                        <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                            <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                               onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                <?php echo e(__('Logout')); ?>

                            </a>

                            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                <?php echo csrf_field(); ?>
                            </form>
                        </div>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH /home/shojib/Desktop/project/Invoice-System-master/resources/views/layouts/shared/navbar.blade.php ENDPATH**/ ?>