<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('access_company')): ?>
<?php $__env->startSection('CssSection'); ?>
    <link href="<?php echo e(asset('css/UserLayout.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?> Company <?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success"><?php echo e(session('status')); ?></div>
    <?php endif; ?>
    <?php if(session('error_msg')): ?>
        <div class="alert alert-success"><?php echo e(session('msg')); ?></div>
    <?php endif; ?>
    <?php if(isset($companies)): ?>
        <a href="<?php echo e(route('company.create')); ?>">Add New Company</a>
        <nav aria-label="...">
            <ul class="pagination">
                <?php for($i=1; $i<=$total; $i++): ?>
                    <li class="page-item"><a class="page-link" id="<?php echo e($i); ?>" onclick="make_active(<?php echo e($i); ?>)"
                                             href="<?php echo e(request()->fullUrlWithQuery(['page'=>$i])); ?>"><?php echo e($i); ?></a></li>
                <?php endfor; ?>

            </ul>
        </nav>

        <form class="d-flex" action="<?php echo e(route('company.index')); ?>" method="GET">
            <input class="form-control me-2" type="search" name="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success" type="submit">Search</button>
        </form>
        <table class="table table-hover">
            <thead>
            <tr>
                <?php if(!request()->has('sort') and !request()->has('order')): ?>
                    <th scope="col" class="column_sort" id="sn">
                        <a href="<?php echo e(request()->fullUrlWithQuery(['sort'=>'desc', 'order'=>'id'])); ?>">SN</a></th>
                    <th scope="col" class="column_sort" id="name"><a
                            href="<?php echo e(request()->fullUrlWithQuery(['sort'=>'desc', 'order'=>'name'])); ?>">
                            Name</a></th>
                    <th scope="col" class="column_sort" id="email">
                        <a href="<?php echo e(request()->fullUrlWithQuery(['sort'=>'desc', 'order'=>'email'])); ?>">Email</a></th>
                <?php elseif(request()->has('sort') and request()->has('order')): ?>
                    <?php
                        if (request()->get('sort')=='desc'){
            $sort='asc';
        }
        else{
            $sort='desc';
        }
                    ?>
                    <th scope="col" class="column_sort" id="sn">
                        <a href="<?php echo e(request()->fullUrlWithQuery(['sort'=>$sort, 'order'=>'id'])); ?>">SN</a></th>
                    <th scope="col" class="column_sort" id="name"><a
                            href="<?php echo e(request()->fullUrlWithQuery(['sort'=>$sort, 'order'=>'name'])); ?>">
                            Name</a></th>
                    <th scope="col" class="column_sort" id="email">
                        <a href="<?php echo e(request()->fullUrlWithQuery(['sort'=>$sort, 'order'=>'email'])); ?>">Email</a></th>

                <?php endif; ?>
                <th scope="col">View</th>
                <th scope="col">Edit</th>
                <th scope="col">Delete</th>
            </tr>
            </thead>
            <tbody id="CompanyTable">


            <?php $index = 1?>
            <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <tr>
                    <td><?php echo e($index); ?></td>
                    <td><?php echo e($company->name); ?></td>
                    <td><?php echo e($company->email); ?></td>
                    <td><a class="fa fa-eye" href="<?php echo e(route('company.show', $company->id)); ?>"></a></td>
                    <td><a class="fa fa-edit" href="<?php echo e(route('company.edit', $company->id)); ?>"></a></td>
                    <td>
                        <form action="<?php echo e(route('company.destroy', $company->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="fa fa-trash"></button>
                        </form>
                    </td>
                </tr>

                <?php $index++;?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><br>
            </tbody>
        </table>
        </tbody>
    <?php else: ?>
        Company Name: <?php echo e($company->name); ?> <br>
        Company Email: <?php echo e($company->email); ?> <br>
        Location: <?php echo e($company->location); ?> <br>
        Contact Number: <?php echo e($company->number); ?>

    <?php endif; ?>
<?php $__env->startSection('JsSection'); ?>
    <script src="<?php echo e(asset('js/UserRetrieve.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shojib/Desktop/project/Invoice-System-master/resources/views/Company/CompanyRetrieve.blade.php ENDPATH**/ ?>