<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
<?php echo $__env->make('layouts.shared.headSection', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('CssSection'); ?>

</head>
<body>
<?php echo $__env->make('layouts.shared.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('body'); ?>
<?php echo $__env->yieldContent('JsSection'); ?>
</body>
</html>
<?php /**PATH /home/shojib/Desktop/project/Invoice-System-master/resources/views/layouts/app.blade.php ENDPATH**/ ?>