<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('manage_role')): ?>
<?php $__env->startSection('CssSection'); ?>
    <link href="<?php echo e(asset('css/UserLayout.css')); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?> User <?php $__env->stopSection(); ?>
<?php $__env->startSection('body'); ?>
    <?php if(session('status')): ?>
        <div class="alert alert-success"><?php echo e(session('status')); ?></div>
    <?php endif; ?>
    <?php if(session('error_msg')): ?>
        <div class="alert alert-success"><?php echo e(session('msg')); ?></div>
    <?php endif; ?>
    <a href="<?php echo e(route('role.create')); ?>">Add New Role</a>

    <table class="table table-hover">
        <thead>
        <tr>
            <th class="text-center">SN</th>
            <th class="text-center">Roles</th>
            <th class="text-center">Permissions</th>
            <th class="text-center">Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $index = 1;?>
        <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($index); ?></td>
                <td><?php echo e($role->name); ?></td>
                <td><?php $__currentLoopData = $role->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($rp['pivot']['role_id']===$role->id): ?>
                            <?php echo e($rp['name']); ?>

                            <br>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                <td><a class="fa fa-edit" href="<?php echo e(route('role.edit', $role->id)); ?>"></a>/
                    <form action="<?php echo e(url('role/'.$role->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="fa fa-trash"></button>
                    </form>
                </td>
            </tr>

            <?php $index++;?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/shojib/Desktop/project/Invoice-System-master/resources/views/Roles/RoleView.blade.php ENDPATH**/ ?>